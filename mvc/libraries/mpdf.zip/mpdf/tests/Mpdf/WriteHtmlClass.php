<?php

namespace Mpdf;

class WriteHtmlClass
{

}
