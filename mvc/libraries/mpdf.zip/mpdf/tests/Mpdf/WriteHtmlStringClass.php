<?php

namespace Mpdf;

class WriteHtmlStringClass
{
	public function __toString()
	{
		return 'special';
	}
}
