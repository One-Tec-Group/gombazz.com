<?php

namespace Mpdf\QrCode;

class QrCodeException extends \Mpdf\MpdfException
{

}
