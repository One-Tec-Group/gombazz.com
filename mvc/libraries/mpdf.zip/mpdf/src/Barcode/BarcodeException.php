<?php

namespace Mpdf\Barcode;

class BarcodeException extends \Mpdf\MpdfException
{

}
